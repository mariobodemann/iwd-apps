# Buster Drone

Model by LaVADraGoN at Sketchfab.

From an joint University Project "Dune Express" Concept-Model was created by my Partner Evil Cloud.

License: CC Attribution-NonCommercial

# Damaged Helmet

Battle Damaged Sci-fi Helmet - PBR by [theblueturtle_](https://sketchfab.com/theblueturtle_)

License: CC Attribution-NonCommercial
